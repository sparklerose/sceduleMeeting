<?php
session_start();

$host     = 'localhost';
$username = 'root';
$password = '';
$dbname   = 'meetingschedule';

// Create a connection to the database
$conn = new mysqli($host, $username, $password, $dbname);

// Check the connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Check if the 'sNum' session variable is set, indicating that the user is logged in
if (!isset($_SESSION['sNum'])) {
    // Redirect to the login page if not logged in
    header("Location: ../index.php");
    exit();
}

// Fetch events data from the events table
$query = "SELECT * FROM events";

$stmt = $conn->prepare($query);
if (!$stmt) {
    echo "Prepare failed: (" . $conn->errno . ") " . $conn->error;
    exit();
}

$stmt->execute();
$result = $stmt->get_result();

// Format events data as JSON
$events = array();
while ($row = $result->fetch_assoc()) {
    $events[] = array(
        'id' => $row['id'],
        'title' => $row['title'],
        'start' => $row['start_event'], // Assuming 'start_event' and 'end_event' are in 'YYYY-MM-DD HH:MM:SS' format
        'end' => $row['end_event'],
        'purpose' => $row['purpose'],
        'venue' => $row['venue'],
    );
}

// Output JSON data
header('Content-Type: application/json');
echo json_encode($events);
?>
