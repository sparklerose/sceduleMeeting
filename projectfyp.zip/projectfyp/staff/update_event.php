<?php
// Start the session
session_start();

// Include the database connection file
include '../db-connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if the form fields are set and not empty
    if (isset($_POST['title'], $_POST['start_event'], $_POST['end_event'], $_POST['purpose'], $_POST['venue'], $_POST['event_id'])) {
        // Sanitize inputs
        $event_id = $_POST['event_id'];
        $title = htmlspecialchars($_POST['title']);
        $start_event = $_POST['start_event'];
        $end_event = $_POST['end_event'];
        $purpose = htmlspecialchars($_POST['purpose']);
        $venue = htmlspecialchars($_POST['venue']);

        // Update the event in the database
        $sql = "UPDATE events SET title=?, start_event=?, end_event=?, purpose=?, venue=? WHERE id=?";
        $stmt = $conn->prepare($sql);
        $stmt->bind_param("sssssi", $title, $start_event, $end_event, $purpose, $venue, $event_id);

        if ($stmt->execute()) {
            // Event updated successfully
            $_SESSION['success_message'] = "Event updated successfully.";
        } else {
            // Error updating event
            $_SESSION['error_message'] = "Error updating event: " . $conn->error;
        }

        // Close prepared statement
        $stmt->close();
    } else {
        // Required fields not set
        $_SESSION['error_message'] = "All fields are required.";
    }

    // Redirect back to the page where the form was submitted from
    header("Location: history.php");
    exit();
} else {
    // If the request method is not POST, redirect to an error page or homepage
    header("Location: fallback.html");
    exit();
}
?>
