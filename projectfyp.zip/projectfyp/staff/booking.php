
<?php
session_start();
include '../db-connect.php';

// Check if the 'level' session variable is set, indicating that the user is logged in
if (!isset($_SESSION['level'])) {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}

$sNum = $_SESSION['sNum']; // Now you can retrieve sNum from the session

// Fetch details for the logged-in user
$sql = "SELECT * FROM users WHERE sNum = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $sNum);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, fetch details
    $userDetails = $result->fetch_assoc();

    // Now you can access user information
    $name = $userDetails['name'];
    $Email = $userDetails['Email'];
    $phoneNum = $userDetails['phoneNum'];
    $officeLoc = $userDetails['officeLoc'];
} else {
    // User not found, handle accordingly (e.g., redirect to login page)
    header("Location: ../index.php");
    exit();
}

// Close the first result set
$stmt->close();

// Fetch users with level '1'
$sql = "SELECT * FROM users WHERE level = '1'";
$resultUsers = $conn->query($sql);

// Fetch busiest hours data
$query = "SELECT HOUR(start_event) as hour, COUNT(*) as count FROM events GROUP BY HOUR(start_event)";
$resultEvents = mysqli_query($conn, $query);

$data = array();
while ($row = mysqli_fetch_assoc($resultEvents)) {
    $data[] = $row;
}

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Book New Event</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/css/bootstrap-datepicker.min.css" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
   
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body id="page-top">
 <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-primary sidebar sidebar-dark accordion"  style="background: linear-gradient(109.6deg, rgba(0, 0, 0, 0.93) 11.2%, rgb(63, 61, 61) 78.9%);" >

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" style="margin-top:20px;" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3"><?= $name ?></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Home -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-bullseye"></i>
                    <span>Home</span></a>
            </li>

			<!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link" href="events.php?user_sNum=<?= $userDetails['sNum']; ?>">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Schedule</span></a>
            </li>
			
			<!-- Nav Item - History -->
            <li class="nav-item ">
                <a class="nav-link" href="history.php">
                    <i class="fas fa-fw fa-hourglass"></i>
                    <span>History</span></a>
            </li>

            <!-- Nav Item - History -->
            <li class="nav-item active">
                <a class="nav-link" href="booking.php">
                    <i class="fas fa-fw fa-hourglass"></i>
                    <span>Booking</span></a>
            </li>
			
			<!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span></a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
		
            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                               
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>
                     </ul>

                </nav>
                <!-- End of Topbar -->
<body>
    <div class="container mt-5">
        <h2>Book New Event</h2>
        <form action="insertSchedule.php" method="post" id="bookingForm">
    <!-- Event Title -->
    <div class="form-group">
        <label for="title">Event Title:</label>
        <input type="text" class="form-control" id="title" name="title" required>
    </div>
    <!-- Start DateTime -->
    <div class="form-group">
        <label for="startDateTime">Start Date and Time:</label>
        <input type="datetime-local" class="form-control" id="startDateTime" name="start_event" required>
    </div>
    <!-- End DateTime -->
    <div class="form-group">
        <label for="endDateTime">End Date and Time:</label>
        <input type="datetime-local" class="form-control" id="endDateTime" name="end_event" required>
    </div>
    <!-- Purpose -->
    <div class="form-group">
        <label for="purpose">Purpose:</label>
        <input type="text" class="form-control" id="purpose" name="purpose" required>
    </div>
    <!-- Venue -->
    <div class="form-group">
        <label for="venue">Venue:</label>
        <input type="text" class="form-control" id="venue" name="venue" required>
    </div>
    <button type="submit" class="btn btn-primary">Submit</button>
</form>

    </div>

    <script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-datepicker/1.9.0/js/bootstrap-datepicker.min.js"></script>
    <script>
        $(document).ready(function() {
            $('.datepicker').datepicker({
                format: 'yyyy-mm-dd',
                autoclose: true,
                todayHighlight: true
            });
        });
    </script>
</body>
</html>
