<?php
session_start();
include '../db-connect.php';

// Check if the 'level' session variable is set, indicating that the user is logged in
if (!isset($_SESSION['level'])) {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}

$sNum = $_SESSION['sNum']; // Now you can retrieve sNum from the session

// Fetch details for the logged-in user
$sql = "SELECT * FROM users WHERE sNum = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $sNum);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, fetch details
    $userDetails = $result->fetch_assoc();

    // Now you can access user information
    $name = $userDetails['name'];
    $Email = $userDetails['Email'];
    $phoneNum = $userDetails['phoneNum'];
    $officeLoc = $userDetails['officeLoc'];
} else {
    // User not found, handle accordingly (e.g., redirect to login page)
    header("Location: ../index.php");
    exit();
}

// Fetch users with level '1'
$sql = "SELECT * FROM users WHERE level = '1'";
$resultUsers = $conn->query($sql);

// Fetch events data for meeting details
$queryEvents = "SELECT * FROM events";
$resultEventsTable = mysqli_query($conn, $queryEvents);

// Close the first result set
$stmt->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>History</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.0.0-alpha.6/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.css">
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
   
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <style>
        /* Popup container */
        .form-popup {
            display: none;
            position: fixed;
            top: 50%;
            left: 50%;
            transform: translate(-50%, -50%);
            border: 3px solid #f1f1f1;
            z-index: 9;
            background-color: #fefefe;
            padding: 20px;
            max-width: 300px;
            width: 80%; /* Adjust width as needed */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            border-radius: 8px;
        }

        /* Full-width input fields */
        .form-popup input[type=text],
        .form-popup input[type=datetime-local] {
            width: 100%;
            padding: 10px;
            margin: 5px 0 15px 0;
            border: 1px solid #ccc;
            border-radius: 5px;
        }

        /* Set a style for the submit button */
        .form-popup .btn {
            background-color: #04AA6D;
            color: white;
            padding: 10px 20px;
            border: none;
            cursor: pointer;
            width: 100%;
            opacity: 0.8;
            border-radius: 5px;
        }

        /* Add a red background color to the cancel button */
        .form-popup .cancel {
            background-color: #f44336;
        }

        /* Hover effects for buttons */
        .form-popup .btn:hover,
        .open-button:hover {
            opacity: 1;
        }

        /* Overlay behind the popup */
        .overlay {
            display: none;
            position: fixed;
            width: 100%;
            height: 100%;
            top: 0;
            left: 0;
            background-color: rgba(0, 0, 0, 0.5); /* Semi-transparent black */
            z-index: 8;
        }
    </style>
</head>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-primary sidebar sidebar-dark accordion" style="background: linear-gradient(109.6deg, rgba(0, 0, 0, 0.93) 11.2%, rgb(63, 61, 61) 78.9%);">

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" style="margin-top:20px;" href="index.html">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <div class="sidebar-brand-text mx-3"><?= $name ?></div>
            </a>

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Home -->
            <li class="nav-item">
                <a class="nav-link" href="index.php">
                    <i class="fas fa-fw fa-bull
                    <i class="fas fa-fw fa-bullseye"></i>
                    <span>Home</span></a>
            </li>

			<!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link" href="events.php?user_sNum=<?= $userDetails['sNum']; ?>">
                    <i class="fas fa-fw fa-table"></i>
                    <span>Schedule</span></a>
            </li>
			
			<!-- Nav Item - History -->
            <li class="nav-item active">
                <a class="nav-link" href="history.php">
                    <i class="fas fa-fw fa-hourglass"></i>
                    <span>History</span></a>
            </li>

            <!-- Nav Item - History -->
            <li class="nav-item">
                <a class="nav-link" href="booking.php">
                    <i class="fas fa-fw fa-hourglass"></i>
                    <span>Booking</span></a>
            </li>
			
			<!-- Nav Item - Schedule -->
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span></a>
            </li>

        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
		
            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <form class="form-inline">
                        <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                            <i class="fa fa-bars"></i>
                        </button>
                    </form>

                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                               
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>
                     </ul>

                </nav>
                <!-- End of Topbar -->
                
                <!-- Main Content Section -->
                <div class="container-fluid">

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Meetings Details</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>Title</th>
                                            <th>Start Time</th>
                                            <th>End Time</th>
                                            <th>Purpose</th>
                                            <th>Venue</th>
                                            <th>Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php while ($event = mysqli_fetch_assoc($resultEventsTable)) : ?>
                                            <tr>
                                                <td><?= $event['title']; ?></td>
                                                <td><?= $event['start_event']; ?></td>
                                                <td><?= $event['end_event']; ?></td>
                                                <td><?= $event['purpose']; ?></td>
                                                <td><?= $event['venue']; ?></td>
                                                <td>

                                                <form action="indexupdate_event.php" method="post">
                                                    <input type="hidden" name="event_id" value="<?= $event['id']; ?>">
                                                    <button type="submit" class="btn btn-success">Update</button>
                                                </form>
                                                    
                                                    <!-- Delete button -->
                                                
                                                <form action="delete_event.php" method="post">
                                                    <input type="hidden" name="event_id" value="<?= $event['id']; ?>">
                                                    <button type="submit" class="btn btn-danger">Delete</button>
                                                </form>
                                             

                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- End of Main Content Section -->
                
            </div>
            <!-- End of Main Content -->

        </div>
        <!-- End of Content Wrapper -->
        
        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

    </div>
    <!-- End of Page Wrapper -->

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/custom.js"></script>

    
</body>

</html>

