<?php
session_start();
include '../db-connect.php'; // Ensure the correct path is used

// Collect and sanitize input
$title = mysqli_real_escape_string($conn, $_POST['title']);
$start_event = mysqli_real_escape_string($conn, str_replace("T", " ", $_POST['start_event']) . ":00"); // Convert to DATETIME format
$end_event = mysqli_real_escape_string($conn, str_replace("T", " ", $_POST['end_event']) . ":00"); // Convert to DATETIME format
$purpose = mysqli_real_escape_string($conn, $_POST['purpose']);
$venue = mysqli_real_escape_string($conn, $_POST['venue']);

// Insert query
$sql = "INSERT INTO events (title, start_event, end_event, purpose, venue) VALUES (?, ?, ?, ?, ?)";
$stmt = $conn->prepare($sql);
if (!$stmt) {
    echo "Error preparing statement: " . $conn->error;
    exit;
}
$stmt->bind_param("sssss", $title, $start_event, $end_event, $purpose, $venue);

if ($stmt->execute()) {
    // Event registration successful
    echo "<script>
            alert('Event registration successful');
            window.location.href = 'booking.php';
          </script>";
} else {
    // Error occurred
    echo "<script>
            alert('Error: " . $stmt->error . "');
            window.location.href = 'booking.php';
          </script>";
}

$stmt->close();
$conn->close();
?>
