<?php
include '../db-connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['event_id'])) {
    $event_id = mysqli_real_escape_string($conn, $_POST['event_id']);

    // SQL to delete the event
    $sql = "DELETE FROM events WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $event_id);

    // Execute the statement
    if ($stmt->execute()) {
        echo "<script>alert('Event deleted successfully.'); window.location.href = 'history.php';</script>";
        exit; // Stop further execution
    } else {
        echo "Error deleting event: " . $conn->error;
    }

    $stmt->close();
    $conn->close();
}
?>
