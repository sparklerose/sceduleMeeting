<?php
session_start();
include '../db-connect.php';

// Check if the 'level' session variable is set, indicating that the user is logged in
if (!isset($_SESSION['level'])) {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}

// Fetch event ID from the form submission
if(isset($_POST['event_id'])) {
    $event_id = $_POST['event_id'];

    // Fetch event data based on the event ID
    $sql = "SELECT * FROM events WHERE id = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("i", $event_id);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $event = $result->fetch_assoc();
    } else {
        // Event not found, handle accordingly (e.g., redirect or display error message)
        echo "Event not found";
        exit();
    }
} else {
    // Redirect if event ID is not provided
    header("Location: history.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Update Event</title>
    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <!-- Custom styles for this template -->
    <link href="css/custom.css" rel="stylesheet">
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
   
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>

</head>

        <!-- Main Content Section -->
        <div class="container-fluid">
            <!-- Update Event Form -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Update Event</h6>
                </div>
                <div class="card-body">
                    <form action="update_event.php" method="post">
                        <!-- Include form fields and pre-fill them with event data -->
                        <!-- Example: -->
                        <input type="hidden" name="event_id" value="<?= $event['id']; ?>">
                        <div class="form-group">
                            <label for="title">Title:</label>
                            <input type="text" class="form-control" id="title" name="title" value="<?= htmlspecialchars($event['title']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="start_event">Start Time:</label>
                            <input type="datetime-local" class="form-control" id="start_event" name="start_event" value="<?= date('Y-m-d\TH:i', strtotime($event['start_event'])); ?>">
                        </div>
                        <div class="form-group">
                            <label for="end_event">End Time:</label>
                            <input type="datetime-local" class="form-control" id="end_event" name="end_event" value="<?= date('Y-m-d\TH:i', strtotime($event['end_event'])); ?>">
                        </div>
                        <div class="form-group">
                            <label for="venue">Venue:</label>
                            <input type="text" class="form-control" id="venue" name="venue" value="<?= htmlspecialchars($event['venue']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="purpose">Purpose:</label>
                            <input type="text" class="form-control" id="purpose" name="purpose" value="<?= htmlspecialchars($event['purpose']); ?>">
                        </div>
                        <!-- Include other form fields as needed -->

                        <button type="submit" class="btn btn-primary">Update</button>
                        <a href="history.php" class="btn btn-secondary">Cancel</a>
                    </form>
                </div>
            </div>
        </div>
        <!-- End of Main Content Section -->
    </div>
    <!-- End of Content Wrapper -->

    <!-- Bootstrap core JavaScript -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
