<?php
include_once("../db-connect.php");

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $name = $_POST["name"];
    $sNum = $_POST["sNum"];
    $email = $_POST["email"];
    $phoneNum = $_POST["phoneNum"];
    $password = $_POST["password"];

    // Assuming you have a database table named 'users'
    $sql = "UPDATE users SET 
            name = '$name', 
            sNum = '$sNum', 
            email = '$email', 
            phoneNum = '$phoneNum'";

    // Update password only if provided
    if (!empty($password)) {
        // Hash the password before storing it in the database
        $hashedPassword = password_hash($password, PASSWORD_DEFAULT);
        $sql .= ", password = '$hashedPassword'";
    }

    // Add your WHERE condition to identify the specific user you want to update
    $sql .= " WHERE sNum = $sNum";

    // Execute the SQL query
    if (mysqli_query($conn, $sql)) {
        // Close the database connection
        mysqli_close($conn);

        // JavaScript code to redirect to profile.php with user_sNum parameter
        echo '<script>
                setTimeout(function() {
					alert("Profile updated successfully");
                    window.location.href = "profile.php?user_sNum=' . $sNum . '";
                }, 100); // 100 milliseconds delay
              </script>';
    } else {
        echo "Error updating profile: " . mysqli_error($conn);
    }
}
?>