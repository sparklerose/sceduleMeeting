<?php
include '../db-connect.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $title = htmlspecialchars($_POST["title"]);
    $start_event = htmlspecialchars($_POST["start_event"]);
    $end_event = htmlspecialchars($_POST["end_event"]);
    $purpose = htmlspecialchars($_POST["purpose"]);
    $status = htmlspecialchars($_POST["status"]);
    $user_id = intval($_POST["user_id"]);
    $staff_id = intval($_POST["staff_id"]);

    // Insert the file information into the database
    $stmt = $conn->prepare("INSERT INTO events (title, start_event, end_event, purpose, status, user_id, staff_id) VALUES (?, ?, ?, ?, ?, ?, ?)");
    $stmt->bind_param("sssssii", $title, $start_event, $end_event, $purpose, $status, $user_id, $staff_id);

    if ($stmt->execute()) {
        echo '<script>
                setTimeout(function() {
                    alert("Appointment Successfully Inserted");
                    window.location.href = "staffSchedule.php?lecturer_sNum=' . $staff_id . '";
                }, 100);
              </script>';
    } else {
        echo "Sorry, there was an error storing information in the database: " . $stmt->error;
    }

    $stmt->close();
}
?>
