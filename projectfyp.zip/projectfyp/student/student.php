<?php
session_start();
include '../db-connect.php';

// Check if the 'level' session variable is set, indicating that the user is logged in
if (!isset($_SESSION['level'])) {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}

$sNum = $_SESSION['sNum']; // Now you can retrieve sNum from the session

// Fetch details for the logged-in user
$sql = "SELECT * FROM users WHERE sNum = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $sNum);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, fetch details
    $userDetails = $result->fetch_assoc();

    // Now you can access user information
    $name = $userDetails['name'];
    $Email = $userDetails['Email'];
    $phoneNum = $userDetails['phoneNum'];
    $officeLoc = $userDetails['officeLoc'];
} else {
    // User not found, handle accordingly (e.g., redirect to login page)
    header("Location: ../index.php");
    exit();
}

// Close the first result set
$stmt->close();

// Fetch users with level '1'
$sql = "SELECT * FROM users WHERE level = '1'";
$resultUsers = $conn->query($sql);

// Fetch busiest hours data
$query = "SELECT HOUR(start_event) as hour, COUNT(*) as count FROM events GROUP BY HOUR(start_event)";
$resultEvents = mysqli_query($conn, $query);

$data = array();
while ($row = mysqli_fetch_assoc($resultEvents)) {
    $data[] = $row;
}

// Fetch events data for meeting details
$queryEvents = "SELECT * FROM events";
$resultEventsTable = mysqli_query($conn, $queryEvents);

// Fetch the top 5 most popular venues based on the number of events
$queryTopVenues = "
    SELECT
        venue,
        COUNT(*) AS num_events
    FROM
        events
    GROUP BY
        venue
    ORDER BY
        num_events DESC
    LIMIT 5
";

$resultTopVenues = $conn->query($queryTopVenues);
$topVenuesData = array();

while ($row = $resultTopVenues->fetch_assoc()) {
    $topVenuesData[] = $row;
}
?>

<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="manifest" href="/manifest.json">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    
    <!-- Custom fonts for this template -->
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
   
    <!-- Custom styles for this template -->
    <link href="css/sb-admin-2.min.css" rel="stylesheet">

    <!-- Custom styles for this page -->
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
   
    <!-- ios support-->
  <link rel="apple-touch-icon" href="/img/logo-96x96.png">
  <meta name="apple-mobile-web-app-status-bar" content="#aa7700">

  

</head>
<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <ul class="navbar-nav bg-primary sidebar sidebar-dark accordion"  style="background: linear-gradient(109.6deg, rgba(0, 0, 0, 0.93) 11.2%, rgb(63, 61, 61) 78.9%);" >

            <!-- Sidebar - Brand -->
            <a class="sidebar-brand d-flex align-items-center justify-content-center" style="margin-top: 20px;">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <?php if (!empty($userDetails)) : ?>
                <div class="sidebar-brand-text mx-3"><?= $userDetails['name']; ?></div>
            </a>
            <?php endif; ?>
            

            <!-- Divider -->
            <hr class="sidebar-divider my-0">

            <!-- Nav Item - Home -->
            <li class="nav-item active">
                <a class="nav-link" href="student.php">
                    <i class="fas fa-fw fa-bullseye"></i>
                    <span>Home</span></a>
            </li>
            
            <!-- Nav Item - History -->
            <li class="nav-item">
                <a class="nav-link" href="schedule.php">
                    <i class="fas fa-fw fa-hourglass"></i>
                    <span>Schedule</span></a>
            </li>

            
            <!-- Nav Item - Profile -->
            <li class="nav-item">
                <a class="nav-link" href="profile.php?user_id=<?= $userDetails['sNum']; ?>">
                    <i class="fas fa-fw fa-users"></i>
                    <span>Profile</span></a>
            </li>
            
            <!-- Nav Item - Logout -->
            <li class="nav-item">
                <a class="nav-link" href="../logout.php">
                    <i class="fas fa-fw fa-sign-out-alt"></i>
                    <span>Logout</span></a>
            </li>

            <!-- Divider -->
            <hr class="sidebar-divider d-none d-md-block">


        </ul>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
        
            <!-- Main Content -->
            <div id="content">

               <!-- Topbar -->
                <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">

                    <!-- Sidebar Toggle (Topbar) -->
                    <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                        <i class="fa fa-bars"></i>
                    </button>


                    <!-- Topbar Navbar -->
                    <ul class="navbar-nav ml-auto">

                        <!-- Nav Item - Search Dropdown (Visible Only XS) -->
                        <li class="nav-item dropdown no-arrow d-sm-none">
                            <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-search fa-fw"></i>
                            </a>
                            <!-- Dropdown - Messages -->
                            <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                                aria-labelledby="searchDropdown">
                                <form class="form-inline mr-auto w-100 navbar-search">
                                    <div class="input-group">
                                        <input type="text" class="form-control bg-light border-0 small"
                                            placeholder="Search for..." aria-label="Search"
                                            aria-describedby="basic-addon2">
                                        <div class="input-group-append">
                                            <button class="btn btn-primary" type="button">
                                                <i class="fas fa-search fa-sm"></i>
                                            </button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </li>

                        <!-- Nav Item - Alerts -->
                        <li class="nav-item dropdown no-arrow mx-1">
                            <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button"
                                data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <i class="fas fa-bell fa-fw"></i>
                                <!-- Counter - Alerts -->
                                <span class="badge badge-danger badge-counter">3+</span>
                            </a>
                            <!-- Dropdown - Alerts -->
                            <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                                aria-labelledby="alertsDropdown">
                                <h6 class="dropdown-header">
                                    Alerts Center
                                </h6>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-primary">
                                            <i class="fas fa-file-alt text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 12, 2019</div>
                                        <span class="font-weight-bold">A new monthly report is ready to download!</span>
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-success">
                                            <i class="fas fa-donate text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 7, 2019</div>
                                        $290.29 has been deposited into your account!
                                    </div>
                                </a>
                                <a class="dropdown-item d-flex align-items-center" href="#">
                                    <div class="mr-3">
                                        <div class="icon-circle bg-warning">
                                            <i class="fas fa-exclamation-triangle text-white"></i>
                                        </div>
                                    </div>
                                    <div>
                                        <div class="small text-gray-500">December 2, 2019</div>
                                        Spending Alert: We've noticed unusually high spending for your account.
                                    </div>
                                </a>
                                <a class="dropdown-item text-center small text-gray-500" href="#">Show All Alerts</a>
                            </div>
                        </li>

                    </ul>

                </nav>
                <!-- End of Topbar -->
                 <div class="container-fluid">
                    <!-- Content Row -->
                    <div class="row">

                        <div class="col-xl-8 col-lg-7">

                            <!-- Area Chart -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                                    <h6 class="m-0 font-weight-bold text-primary">Busiest hours for Meetings</h6>
                                </div>
                                 <div class="card-body">
                                        <canvas id="busiestHoursChart"></canvas>
                                 </div>
                            </div>
                        </div>

                        <!-- Donut Chart -->
<div class="col-xl-4 col-lg-5">
    <div class="card shadow mb-4">
        <!-- Card Header - Dropdown -->
        <div class="card-header py-3">
            <h6 class="m-0 font-weight-bold text-primary">Top 5 Most Popular Venue</h6>
        </div>
        <!-- Card Body -->
        <div class="card-body">
            <div class="chart-pie pt-4 pb-2">
                <canvas id="topVenuesChart"></canvas> <!-- Add this canvas for displaying the bar chart -->
            </div>
        </div>
    </div>
</div>

                <!-- Begin Page Content -->
                <div class="container-fluid">

                   
                    <!-- DataTales Example -->
<div class="card shadow mb-4">
    <div class="card-header py-3">
        <h6 class="m-0 font-weight-bold text-primary">Meetings Details</h6>
    </div>
    <div class="card-body">
        <div class="table-responsive">
            <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                <thead>
                    <tr>
                        <th>Title</th>
                        <th>Start Time</th>
                        <th>End Time</th>
                        <th>Purpose</th>
                        <th>Venue</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($event = mysqli_fetch_assoc($resultEventsTable)) : ?>
                    <tr>
                        <td><?= $event['title']; ?></td>
                        <td><?= $event['start_event']; ?></td>
                        <td><?= $event['end_event']; ?></td>
                        <td><?= $event['purpose']; ?></td>
                        <td><?= $event['venue']; ?></td>
                    </tr>
                    <?php endwhile; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


           

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Bootstrap core JavaScript-->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

    <!-- Core plugin JavaScript-->
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>

    <!-- Custom scripts for all pages-->
    <script src="js/sb-admin-2.min.js"></script>

    <!-- Page level plugins -->
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>

    <!-- Page level custom scripts -->
    <script src="js/demo/datatables-demo.js"></script>
    <script>
    document.addEventListener('DOMContentLoaded', function() {
        // Prepare data from PHP
        var phpData = <?php echo json_encode($data); ?>;

        // Extract hours and counts
        var hours = phpData.map(function(item) { return item.hour; });
        var counts = phpData.map(function(item) { return item.count; });

        // Create the line chart
        var ctx = document.getElementById('busiestHoursChart').getContext('2d');
        var busiestHoursChart = new Chart(ctx, {
            type: 'line',
            data: {
                labels: hours,
                datasets: [{
                    label: 'Busiest Hours',
                    data: counts,
                    backgroundColor: 'rgba(75, 192, 192, 0.2)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    x: {
                        type: 'linear',
                        position: 'bottom',
                        title: {
                            display: true,
                            text: 'Hour of Day'
                        }
                    },
                    y: {
                        beginAtZero: true,
                        title: {
                            display: true,
                            text: 'Number of Appointments'
                        }
                    }
                }
            }
        });
    });
</script>
<script>
    document.addEventListener('DOMContentLoaded', function() {
        // Prepare data from PHP
        var phpTopLecturersData = <?php echo json_encode($topLecturersData); ?>;

        // Extract appointment counts
        var appointmentCounts = phpTopLecturersData.map(function(item) { return item.num_appointments; });

        // Create an array of generic labels
        var genericLabels = Array.from({length: appointmentCounts.length}, (_, i) => 'Lecturer ' + (i + 1));

        // Create the bar chart
        var ctx = document.getElementById('topLecturersChart').getContext('2d');
        var topLecturersChart = new Chart(ctx, {
            type: 'bar',
            data: {
                labels: genericLabels,
                datasets: [{
                    label: 'Number of Appointments',
                    data: appointmentCounts,
                    backgroundColor: 'rgba(75, 192, 192, 0.6)',
                    borderColor: 'rgba(75, 192, 192, 1)',
                    borderWidth: 1
                }]
            },
            options: {
                scales: {
                    x: {
                        beginAtZero: true
                    },
                    y: {
                        position: 'bottom' // Set y-axis labels to be at the bottom
                    }
                }
            }
        });
    });
</script>
<!-- Custom JavaScript -->
<script>
        // Prepare data for the top 5 most popular venues
        var topVenuesData = <?php echo json_encode($topVenuesData); ?>;

        // Extract venue names and event counts
        var venueNames = topVenuesData.map(function(item) { return item.venue; });
        var eventCounts = topVenuesData.map(function(item) { return item.num_events; });

        // Create a bar chart for the top 5 most popular venues
        var ctx = document.getElementById('topVenuesChart').getContext('2d');
        var topVenuesChart = new Chart(ctx, {
    type: 'bar',
    data: {
        labels: venueNames,
        datasets: [{
            label: 'Number of Events',
            data: eventCounts,
            backgroundColor: 'rgba(54, 162, 235, 0.6)',
            borderColor: 'rgba(54, 162, 235, 1)',
            borderWidth: 1
        }]
    },
    options: {
        scales: {
            y: { // Use 'y' instead of 'yAxes'
                beginAtZero: true
            }
        }
    }
});

    </script>

    <script src="\js\app.js></script>

    


</body>

</html>
