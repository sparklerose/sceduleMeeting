<?php
session_start();
include '../db-connect.php';

// Check if the 'level' session variable is set, indicating that the user is logged in
if (!isset($_SESSION['level'])) {
    header("Location: ../index.php"); // Redirect to the login page if not logged in
    exit();
}

$sNum = $_SESSION['sNum']; // Now you can retrieve sNum from the session

// Fetch details for the logged-in user
$sql = "SELECT * FROM users WHERE sNum = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $sNum);
$stmt->execute();
$result = $stmt->get_result();

if ($result->num_rows > 0) {
    // User found, fetch details
    $userDetails = $result->fetch_assoc();

    // Now you can access user information
    $name = $userDetails['name'];
    $Email = $userDetails['Email'];
    $phoneNum = $userDetails['phoneNum'];
    $officeLoc = $userDetails['officeLoc'];
} else {
    // User not found, handle accordingly (e.g., redirect to login page)
    header("Location: ../index.php");
    exit();
}

// Close the first result set
$stmt->close();

// Fetch users with level '1'
$sql = "SELECT * FROM users WHERE level = '1'";
$resultUsers = $conn->query($sql);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="manifest" href="/manifest.json">
    <title>Calendar with Events</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.css" />
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/moment.js/2.18.1/moment.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/fullcalendar/3.4.0/fullcalendar.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    
    <!-- ios support-->
  <link rel="apple-touch-icon" href="/img/logo-96x96.png">
  <meta name="apple-mobile-web-app-status-bar" content="#aa7700">


</head>
<body id="page-top">

<!-- Page Wrapper -->
<div id="wrapper">

    <!-- Sidebar -->
    <ul class="navbar-nav bg-primary sidebar sidebar-dark accordion" style="background: linear-gradient(109.6deg, rgba(0, 0, 0, 0.93) 11.2%, rgb(63, 61, 61) 78.9%);">
        <!-- Sidebar - Brand -->
        <a class="sidebar-brand d-flex align-items-center justify-content-center" style="margin-top: 20px;">
                <div class="sidebar-brand-icon rotate-n-15">
                    <i class="fas fa-laugh-wink"></i>
                </div>
                <?php if (!empty($userDetails)) : ?>
                <div class="sidebar-brand-text mx-3"><?= $userDetails['name']; ?></div>
            </a>
            <?php endif; ?>
        <!-- Divider -->
        <hr class="sidebar-divider my-0">
        <!-- Nav Item - Home -->
        <li class="nav-item">
            <a class="nav-link" href="student.php">
                <i class="fas fa-fw fa-bullseye"></i>
                <span>Home</span></a>
        </li>
        <!-- Nav Item - History -->
        <li class="nav-item active">
            <a class="nav-link" href="schedule.php">
                <i class="fas fa-fw fa-hourglass"></i>
                <span>Schedule</span></a>
        </li>
        <!-- Nav Item - Profile -->
        <li class="nav-item">
            <a class="nav-link" href="profile.php?user_id=<?= $userDetails['sNum']; ?>">
                <i class="fas fa-fw fa-users"></i>
                <span>Profile</span></a>
        </li>
        <!-- Nav Item - Logout -->
        <li class="nav-item">
            <a class="nav-link" href="../logout.php">
                <i class="fas fa-fw fa-sign-out-alt"></i>
                <span>Logout</span></a>
        </li>
        <!-- Divider -->
        <hr class="sidebar-divider d-none d-md-block">
    </ul>
    <!-- End of Sidebar -->

    <!-- Content Wrapper -->
    <div id="content-wrapper" class="d-flex flex-column">

        <!-- Main Content -->
        <div id="content">

            <!-- Topbar -->
            <nav class="navbar navbar-expand navbar-light bg-white topbar mb-4 static-top shadow">
                <!-- Sidebar Toggle (Topbar) -->
                <button id="sidebarToggleTop" class="btn btn-link d-md-none rounded-circle mr-3">
                    <i class="fa fa-bars"></i>
                </button>
            </nav>
            <!-- End of Topbar -->

            <!-- Begin Page Content -->
            <div class="container-fluid">

                <!-- Page Heading -->
                <h1 class="h3 mb-4 text-gray-800">Calendar with Events</h1>

                <!-- Calendar Container -->
                <div id="calendar-container" class="calendar-container">
                    <div id="calendar"></div>
                </div>

            </div>
            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

    </div>
    <!-- End of Content Wrapper -->

</div>
<!-- End of Page Wrapper -->

<!-- Scroll to Top Button-->
<a class="scroll-to-top rounded" href="#page-top">
    <i class="fas fa-angle-up"></i>
</a>

<!-- Core JavaScript-->
<script>
    $(document).ready(function () {
            $('#calendar').fullCalendar({
                header: {
                    left: 'prev,next today',
                    center: 'title',
                    right: 'month,agendaWeek,agendaDay'
                },
                events: 'load.php', // Assuming load.php is in the same directory
                eventClick: function (event) {
                    // Example of showing a simple alert on event click
                    alert('Event: ' + event.title + '\nVenue: ' + event.venue + '\nStart Time: ' + event.start.format('YYYY-MM-DD HH:mm:ss') + '\nEnd Time: ' + event.end.format('YYYY-MM-DD HH:mm:ss'));
                    // You can replace this alert with a more complex modal popup
                }
            });
        });
</script>


</body>
</html>
